This VPN Provider currently has three days free trial.
And does not require a Credit card or any personal information to obtain it.
You can achieve pretty good attack speed using it.
And you can create such accounts many times using the instructions below.


Here is an instruction:

1. Use your cell phone any other method to change your IP address
2. Open new incognito tab in a browser
3. Visit https://www.cactusvpn.com/vpn-free-trial/
4. Use fresh email to register. There are many ways to get email aliases nowadays
5. You will receive two emails to your email.
6. Copy the link to "Confirm email" from your email app and paste it into your
   incognito browser window, where you have previously registered
7. Do the same with "Create password" link
8. Visit
   https://billing.cactusvpn.com/vpn-username-password.php
   to obtain your credentials for X100's credentials.txt file

Here is the link to archive with .ovpn files
https://github.com/ihorlv/db1000nX100/raw/main/open-vpn-providers/cactus-vpn.zip

I have already excluded RU-Moscow-CactusVPN-UDP.ovpn


