#!/usr/bin/env bash

# For user custom scripts