#!/usr/bin/env bash

# For user's custom scripts

